require("BiocGenerics") || stop("unable to load BiocGenerics package")
BiocGenerics:::.test()
